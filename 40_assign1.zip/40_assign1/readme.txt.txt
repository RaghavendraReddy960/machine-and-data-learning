assumptions taken.
1. we took absolute value for ie 